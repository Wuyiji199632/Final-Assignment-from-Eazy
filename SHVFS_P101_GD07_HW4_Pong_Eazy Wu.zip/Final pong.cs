﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Remake_for_Pong_2
{
    class Program
    {
        public static int PlayerOneScore { get; private set; }
        public static int PlayerTwoScore { get; private set; }
        public static int PlayerLength = 8;
        public struct Vector2
        {
            public int x;
            public int y;
            public Vector2(int x, int y)
            {
                this.x = x;
                this.y = y;
            }
            public static readonly Vector2 Up = new Vector2(0, -1);
            public static readonly Vector2 Down = new Vector2(0, 1);
            public static Vector2 operator +(Vector2 v1, Vector2 v2)
            {
                return new Vector2(v1.x + v2.x, v1.y + v2.y);
            }
            public static Vector2 operator -(Vector2 v)
            {
                return new Vector2(-v.x, -v.y);
            }
            public static bool operator ==(Vector2 v1, Vector2 v2)
            {
                return (v1.x == v2.x && v1.y == v2.y);
            }
            public static bool operator !=(Vector2 v1, Vector2 v2)
            {
                return (v1.x != v2.x || v1.y != v2.y);
            }
        }

        public class Player
        {
            public Vector2 Direction;
            public Vector2 Position;
            int PlayerOneScore = 0;
            int PlayerTwoScore = 0;
            public Dictionary<ConsoleKey, Vector2> InputDirections;
        }
        private static Player PlayerOne = new Player()
        {
            InputDirections = new Dictionary<ConsoleKey, Vector2>()
           {
           {ConsoleKey.W,Vector2.Up},
           {ConsoleKey.S,Vector2.Down},
        }
        };
        private static Player PlayerTwo = new Player()
        {
            InputDirections = new Dictionary<ConsoleKey, Vector2>()
           {
           {ConsoleKey.UpArrow,Vector2.Up},
           {ConsoleKey.DownArrow,Vector2.Down},
        }
        };
        public class ball
        {
            public Vector2 direction;
            public Vector2 position;
        }
        public static ball ballMovement = new ball()
        {
            direction = new Vector2(1, 1)
        };
        private static void DrawPaddle(int PositionX, int PositionY, char icon1, ConsoleColor color)
        {
            color = ConsoleColor.Yellow;
            Console.SetCursorPosition(PositionX, PositionY);
            Console.Write(icon1);
        }
        private static void Drawball(int positionX, int positionY, int directionX, int directionY, char icon2, ConsoleColor color)
        {
            color = ConsoleColor.Blue;
            Console.SetCursorPosition(positionX, positionY);
            Console.Write(icon2);
            int timescale = 80;
            Thread.Sleep(timescale);
        }
        static void Main(string[] args)
        {
            while (true)
            {
                #region
                PlayerOneScore = 0;
                PlayerTwoScore = 0;
                Console.CursorVisible = false;
                Console.WindowHeight = 30;
                Console.WindowWidth = 100;
                Console.BufferHeight = 30;
                Console.BufferWidth = 100;
                var title = "Pong Game";
                Console.CursorLeft = Console.WindowWidth / 2 - title.Length / 2;
                Console.WriteLine(title);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("player one's control:\n" + "W-Up\n" + "S-Down");
                var playerTwoControlTitle = "player Two's control:";
                var playerTwoControlTitleCursorPosition = Console.BufferWidth - playerTwoControlTitle.Length;
                Console.CursorTop = 1;
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.CursorLeft = playerTwoControlTitleCursorPosition;
                Console.WriteLine("Up Arrow-Up");
                Console.CursorLeft = playerTwoControlTitleCursorPosition;
                Console.WriteLine("Down Arrow-Down");
                #endregion


                while (PlayerOneScore <= 3 && PlayerTwoScore <= 3)
                {
                    PlayerOne.Position.x = 4;
                    PlayerOne.Position.y = Console.WindowHeight / 2 - PlayerLength / 2;
                    PlayerTwo.Position.x = Console.WindowWidth - 4;
                    PlayerTwo.Position.y = Console.WindowHeight / 2 - PlayerLength / 2;
                    ballMovement.position.x = Console.WindowWidth / 2;
                    ballMovement.position.y = Console.WindowHeight / 2;
                    ballMovement.direction.x = 2;
                    ballMovement.direction.y = 1;
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.CursorTop = 4;
                    Console.CursorLeft = Console.WindowWidth / 2;
                    Console.WriteLine(PlayerOneScore + ":" + PlayerTwoScore);

                    while (true)
                    {
                        if (Console.KeyAvailable)
                        {
                            var key = Console.ReadKey(true);
                            if (key.Key == ConsoleKey.W)
                            {
                                PlayerOne.Direction = Vector2.Up;
                                PlayerOne.Position += PlayerOne.Direction;
                                if (PlayerOne.Position.y < 0)
                                {
                                    PlayerOne.Position = new Vector2(PlayerOne.Position.x, 0);
                                }
                                Console.Clear();
                            }
                            if (key.Key == ConsoleKey.S)
                            {
                                PlayerOne.Direction = Vector2.Down;
                                PlayerOne.Position += PlayerOne.Direction;
                                if (PlayerOne.Position.y >= Console.WindowHeight - 8)
                                {
                                    PlayerOne.Position = new Vector2(4, Console.WindowHeight - 9);
                                }
                                Console.Clear();
                            }

                            if (key.Key == ConsoleKey.UpArrow)
                            {
                                PlayerTwo.Direction = Vector2.Up;
                                PlayerTwo.Position += PlayerTwo.Direction;
                                if (PlayerTwo.Position.y < 0)
                                {
                                    PlayerTwo.Position = new Vector2(PlayerTwo.Position.x, 0);
                                }
                                Console.Clear();
                            }
                            if (key.Key == ConsoleKey.DownArrow)
                            {
                                PlayerTwo.Direction = Vector2.Down;
                                PlayerTwo.Position += PlayerTwo.Direction;
                                if (PlayerTwo.Position.y >= Console.WindowHeight - 8)
                                {
                                    PlayerTwo.Position = new Vector2(PlayerTwo.Position.x, Console.WindowHeight - 8);
                                }
                                Console.Clear();
                            }
                        
                            for (int i = 0; i < PlayerLength; i++)
                            {
                                DrawPaddle(PlayerOne.Position.x, PlayerOne.Position.y + i, '|', ConsoleColor.Green);
                                DrawPaddle(PlayerTwo.Position.x, PlayerTwo.Position.y + i, '|', ConsoleColor.Blue);
                            }
                            Drawball(ballMovement.position.x, ballMovement.position.y, ballMovement.direction.x, ballMovement.direction.y, '@', ConsoleColor.Cyan);
                            ballMovement.position += ballMovement.direction;
                            Console.Clear();
                            if (ballMovement.position.y == Console.WindowHeight - 1 || ballMovement.position.y == 1)
                            {
                                ballMovement.direction = new Vector2(ballMovement.direction.x, -ballMovement.direction.y);
                            }
                            for (int i = 0; i < PlayerLength; i++)
                            {
                                if (ballMovement.position.x == PlayerOne.Position.x && ballMovement.position.y == PlayerOne.Position.y + i)
                                {
                                    ballMovement.direction = new Vector2(-ballMovement.direction.x, ballMovement.direction.y);
                                }
                                if (ballMovement.position.x == PlayerTwo.Position.x && ballMovement.position.y == PlayerTwo.Position.y + i)
                                {
                                    ballMovement.direction = new Vector2(-ballMovement.direction.x, ballMovement.direction.y);
                                }
                                if (ballMovement.position.x >= Console.WindowWidth)
                                {
                                    PlayerOneScore++;
                                    Console.WriteLine(PlayerOneScore);
                                    Console.ReadLine();
                                    ballMovement.position.x = Console.WindowWidth / 2 - 1;
                                    ballMovement.position.y = Console.WindowHeight / 2 - 1;

                                }
                                if (ballMovement.position.x <= 0)
                                {
                                    PlayerTwoScore++;
                                    Console.WriteLine(PlayerTwoScore);
                                    Console.ReadLine();
                                    ballMovement.position.x = Console.WindowWidth / 2 - 1;
                                    ballMovement.position.y = Console.WindowHeight / 2 - 1;
                                   
                                }

                            }
                        }
                        if (PlayerOneScore == 3)
                        {
                            Console.CursorTop = Console.WindowHeight / 2;
                            string FinalResult = "PlayerOne Wins";
                            Console.CursorLeft = Console.WindowWidth / 2 - FinalResult.Length / 2;
                            Console.WriteLine(FinalResult);

                        }
                        else if (PlayerTwoScore == 3)
                        {
                            Console.CursorTop = Console.WindowHeight / 2;
                            string FinalResult = "PlayerTwo Wins";
                            Console.CursorLeft = Console.WindowWidth / 2 - FinalResult.Length / 2;
                            Console.WriteLine(FinalResult);
                        }

                    }

                }
            }
        }
    }
}
